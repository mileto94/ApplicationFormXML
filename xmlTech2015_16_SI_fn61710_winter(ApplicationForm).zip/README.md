# Application Form for applying for optional courses in FMI
### for XML course

This document describes the archive's content:
- xmlTech2015_16_SI_fn61710_winter.pdf
- ApplicationForm folder with .exe file to start the project

## Start project
Extract files from the archive in new directory and run:
> .\ApplicationForm\ApplicationForm\bin\Release.exe
